# -*- coding: utf-8 -*-

from . import leave_request_report_wizard
from . import student_report_wizard
