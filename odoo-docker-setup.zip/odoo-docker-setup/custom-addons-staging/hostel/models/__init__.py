# -*- coding: utf-8 -*-
"""init file of all models"""

from . import cleaning_service
from . import hostel_facility
from . import hostel_invoice
from . import hostel_room
from . import hostel_student
from . import leave_request
