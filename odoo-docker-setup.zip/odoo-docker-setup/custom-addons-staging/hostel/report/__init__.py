# -*- coding: utf-8 -*-

from . import leave_request_report
from . import student_report
